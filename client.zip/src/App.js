
import './App.css';
import { BrowserRouter, Switch, Route } from "react-router-dom";
import { useDispatch,useSelector } from "react-redux";
import Header from './components/Header/Header'
import LoginScreen from './screens/LoginScreen'
import RegisterScreen from './screens/RegisterScreen';
import HomeScreen from './screens/HomeScreen';
import { useEffect } from 'react';
import { validateToken } from './actions/userActions';
import VerifyMailScreen from './screens/VerifyMailScreen';

function App() {
  const dispatch = useDispatch();
  const userLogin = useSelector(state => state.userLogin);
  console.log(userLogin);
    // const {userLogin, userStatus } = userLoginData;
    const { loading, error, userInfo } = userLogin; 
    const token = userInfo ? userInfo.token : null;
  // useEffect(()=>{
  //   if(token){
  //     dispatch(validateToken(token));
  //   }
  // },[token])
  return (
    <>
      <BrowserRouter>
          <Header />
          <main>
              <Switch>
              <Route exact path="/" component={HomeScreen} />
              <Route path="/login" component={LoginScreen} />
              <Route path="/register" component={RegisterScreen} />
              <Route path="/verify-mail" component={VerifyMailScreen} />
              {/* <Route path="/verify-mail" component={VerifyMail} />
              <Route path="/verify-account/:userId/:secretCode" component={ActivateAccount} />
              <Route path="/forget-password" component={ForgetPassword} />
              <Route path="/reset-password" component={ResetPassword} />
              <Route path="/userhome" component={UserHome}/>
              <Route path="/logout" component={Logout}/>
              <Route path="/completed-todos" component={CompletedTodos}/> */}
            </Switch>
          </main>
      </BrowserRouter>
    </>
  );
}

export default App;
