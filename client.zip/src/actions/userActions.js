import axios from 'axios'
import {
  USER_LOGIN_FAILURE,
  USER_LOGIN_REQUEST,
  USER_LOGIN_SUCCESS,
  
  USER_REGISTER_FAILURE,
  USER_REGISTER_REQUEST,
  USER_REGISTER_SUCCESS,
  
  VALIDATE_TOKEN_FAILURE,
  VALIDATE_TOKEN_REQUEST,
  VALIDATE_TOKEN_SUCCESS,

  VERIFY_MAIL_FAILURE,
  VERIFY_MAIL_REQUEST,
  VERIFY_MAIL_SUCCESS,
  
} from '../constants/userConstants'

import { HOST_URL } from '../constants/appConstants'

export const validateToken = (token) => async (dispatch) =>{
   try{
     console.log(token);
     dispatch({
       type : VALIDATE_TOKEN_REQUEST
     })
     const config = {
      headers: {
        'Content-Type': 'application/json',
        "Authorization" : `Bearer ${token}`
      },
    }

    const { data } = await axios.post(
      `${HOST_URL}/api/auth/validate-token`,
      null,
      config
    )
    if(data && data.userStatus === 'active'){
      dispatch({
        type: VALIDATE_TOKEN_SUCCESS,
        payload: true,
      })
    }
    else{
      dispatch({
        type: VALIDATE_TOKEN_SUCCESS,
        payload: false,
      })
    }
    

    // localStorage.setItem('userInfo', JSON.stringify(data))
   }
   catch(error){
    dispatch({
      type: VALIDATE_TOKEN_FAILURE,
      payload:
        error.response && error.response.data.message
          ? error.response.data.message
          : error.message,
    })
   }
}

export const login = (email, password) => async (dispatch) => {
  try {
    dispatch({
      type: USER_LOGIN_REQUEST,
    })

    const config = {
      headers: {
        'Content-Type': 'application/json',
      },
    }

    const { data } = await axios.post(
      `${HOST_URL}/api/auth/login`,
      { email, password },
      config
    )

    // dispatch({
    //   type: USER_LOGIN_SUCCESS,
    //   payload: data,
    // })

    if(data.success){
      dispatch({
        type: USER_LOGIN_SUCCESS,
        payload: data,
      })
      localStorage.setItem('userInfo', JSON.stringify(data))
    }
    else{
      dispatch({
        type : USER_LOGIN_FAILURE,
        payload : data.errors[0].msg
      })
    }

    localStorage.setItem('userInfo', JSON.stringify(data))
  } catch (error) {
    dispatch({
      type: USER_LOGIN_FAILURE,
      payload:
        error.response && error.response.data.message
          ? error.response.data.message
          : error.message,
    })
  }
}

export const register = (firstName,lastName, email, password, confirmPassword) => async (dispatch) => {
  console.log(firstName);
    try {
      dispatch({
        type: USER_REGISTER_REQUEST,
      })
  
      const config = {
        headers: {
          'Content-Type': 'application/json',
        },
      }
  
      const { data } = await axios.post(
        `${HOST_URL}/api/auth/register`,
        { firstName,lastName, email, password, confirmPassword },
        config
      )
      console.log(data);
      if(data.success){
        dispatch({
          type: USER_REGISTER_SUCCESS,
          payload: data,
        })
        localStorage.setItem('userInfo', JSON.stringify(data))
      }
      else{
        dispatch({
          type : USER_REGISTER_FAILURE,
          payload : data.errors[0].msg
        })
      }
  
      
  
      // dispatch({
      //   type: USER_LOGIN_SUCCESS,
      //   payload: data,
      // })
  
      
    } catch (error) {
      console.log(error);
      dispatch({
        type: USER_REGISTER_FAILURE,
        payload:
          error.response && error.response.data.message
            ? error.response.data.message
            : error.message,
      })
    }
  }

  export const UserVerifyMail = (token) => async (dispatch) => {
    try {
      dispatch({
        type: VERIFY_MAIL_REQUEST,
      })
  
      const config = {
        headers: {
          'Content-Type': 'application/json',
          "Authorization" : `Bearer ${token}`
        },
      }
  
      const { data } = await axios.get(
        `${HOST_URL}/api/auth/verification/get-activation-email`,
        config
      )
      if(data.success){
        dispatch({
          type: VERIFY_MAIL_SUCCESS,
          payload: data,
        })
      }
      else{
        dispatch({
          type : VERIFY_MAIL_FAILURE,
          payload : data,
        })
      }
  
      // dispatch({
      //   type: VERIFY_MAIL_SUCCESS,
      //   payload: data,
      // })
  
    } catch (error) {
      dispatch({
        type: VERIFY_MAIL_FAILURE,
        payload:
          error.response && error.response.data.message
            ? error.response.data.message
            : error.message,
      })
    }
  }
// export const logout = () => (dispatch) => {
//   localStorage.removeItem('userInfo')
//   localStorage.removeItem('cartItems')
//   localStorage.removeItem('shippingAddress')
//   localStorage.removeItem('paymentMethod')
//   dispatch({ type: USER_LOGOUT })
//   dispatch({ type: USER_DETAILS_RESET })
//   dispatch({ type: ORDER_LIST_MY_RESET })
//   dispatch({ type: USER_LIST_RESET })
//   document.location.href = '/login'
// }



// export const getUserDetails = (id) => async (dispatch, getState) => {
//   try {
//     dispatch({
//       type: USER_DETAILS_REQUEST,
//     })

//     const {
//       userLogin: { userInfo },
//     } = getState()

//     const config = {
//       headers: {
//         Authorization: `Bearer ${userInfo.token}`,
//       },
//     }

//     const { data } = await axios.get(`/api/users/${id}`, config)

//     dispatch({
//       type: USER_DETAILS_SUCCESS,
//       payload: data,
//     })
//   } catch (error) {
//     const message =
//       error.response && error.response.data.message
//         ? error.response.data.message
//         : error.message
//     if (message === 'Not authorized, token failed') {
//       dispatch(logout())
//     }
//     dispatch({
//       type: USER_DETAILS_FAIL,
//       payload: message,
//     })
//   }
// }

// export const updateUserProfile = (user) => async (dispatch, getState) => {
//   try {
//     dispatch({
//       type: USER_UPDATE_PROFILE_REQUEST,
//     })

//     const {
//       userLogin: { userInfo },
//     } = getState()

//     const config = {
//       headers: {
//         'Content-Type': 'application/json',
//         Authorization: `Bearer ${userInfo.token}`,
//       },
//     }

//     const { data } = await axios.put(`/api/users/profile`, user, config)

//     dispatch({
//       type: USER_UPDATE_PROFILE_SUCCESS,
//       payload: data,
//     })
//     dispatch({
//       type: USER_LOGIN_SUCCESS,
//       payload: data,
//     })
//     localStorage.setItem('userInfo', JSON.stringify(data))
//   } catch (error) {
//     const message =
//       error.response && error.response.data.message
//         ? error.response.data.message
//         : error.message
//     if (message === 'Not authorized, token failed') {
//       dispatch(logout())
//     }
//     dispatch({
//       type: USER_UPDATE_PROFILE_FAIL,
//       payload: message,
//     })
//   }
// }

// export const listUsers = () => async (dispatch, getState) => {
//   try {
//     dispatch({
//       type: USER_LIST_REQUEST,
//     })

//     const {
//       userLogin: { userInfo },
//     } = getState()

//     const config = {
//       headers: {
//         Authorization: `Bearer ${userInfo.token}`,
//       },
//     }

//     const { data } = await axios.get(`/api/users`, config)

//     dispatch({
//       type: USER_LIST_SUCCESS,
//       payload: data,
//     })
//   } catch (error) {
//     const message =
//       error.response && error.response.data.message
//         ? error.response.data.message
//         : error.message
//     if (message === 'Not authorized, token failed') {
//       dispatch(logout())
//     }
//     dispatch({
//       type: USER_LIST_FAIL,
//       payload: message,
//     })
//   }
// }

// export const deleteUser = (id) => async (dispatch, getState) => {
//   try {
//     dispatch({
//       type: USER_DELETE_REQUEST,
//     })

//     const {
//       userLogin: { userInfo },
//     } = getState()

//     const config = {
//       headers: {
//         Authorization: `Bearer ${userInfo.token}`,
//       },
//     }

//     await axios.delete(`/api/users/${id}`, config)

//     dispatch({ type: USER_DELETE_SUCCESS })
//   } catch (error) {
//     const message =
//       error.response && error.response.data.message
//         ? error.response.data.message
//         : error.message
//     if (message === 'Not authorized, token failed') {
//       dispatch(logout())
//     }
//     dispatch({
//       type: USER_DELETE_FAIL,
//       payload: message,
//     })
//   }
// }

// export const updateUser = (user) => async (dispatch, getState) => {
//   try {
//     dispatch({
//       type: USER_UPDATE_REQUEST,
//     })

//     const {
//       userLogin: { userInfo },
//     } = getState()

//     const config = {
//       headers: {
//         'Content-Type': 'application/json',
//         Authorization: `Bearer ${userInfo.token}`,
//       },
//     }

//     const { data } = await axios.put(`/api/users/${user._id}`, user, config)

//     dispatch({ type: USER_UPDATE_SUCCESS })

//     dispatch({ type: USER_DETAILS_SUCCESS, payload: data })

//     dispatch({ type: USER_DETAILS_RESET })
//   } catch (error) {
//     const message =
//       error.response && error.response.data.message
//         ? error.response.data.message
//         : error.message
//     if (message === 'Not authorized, token failed') {
//       dispatch(logout())
//     }
//     dispatch({
//       type: USER_UPDATE_FAIL,
//       payload: message,
//     })
//   }
// }
