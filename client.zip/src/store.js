import { createStore, combineReducers, applyMiddleware } from 'redux'
import thunk from 'redux-thunk'
import { composeWithDevTools } from 'redux-devtools-extension'
import jwt from 'jsonwebtoken'

import { userLoginReducer,userRegisterReducer, userVerifyMailReducer, validateTokenReducer } from './reducers/userReducers'
import { useDispatch } from 'react-redux'

const reducer = combineReducers({
    userLogin : userLoginReducer,
    userRegister : userRegisterReducer,
    verifyMail : userVerifyMailReducer,
    validateToken : validateTokenReducer
    // isLoggedIn : isLoggedInReducer
})

const userInfoFromStorage = localStorage.getItem('userInfo')
  ? JSON.parse(localStorage.getItem('userInfo'))
  : null




const checkTokenExpirationMiddleware = state =>next => action =>{
  const token =
    userInfoFromStorage &&
    userInfoFromStorage.token;
  if (token && jwt.decode(token).exp < Date.now() / 1000) {
    next(action);
    localStorage.clear();
  }
  next(action);
};

// console.log(initialState);

const middleware = [thunk]

const store = createStore(
    reducer,
    composeWithDevTools(applyMiddleware(...middleware,checkTokenExpirationMiddleware))
)
  

export default store
