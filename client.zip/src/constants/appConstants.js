module.exports = {
    HOST_URL : 'http://localhost:5000'
}