import React, { useState,useEffect, useContext,useCallback } from "react";
import { useHistory } from "react-router-dom";
import {useSelector,useDispatch} from 'react-redux'
import Axios from "axios";

import Loading from "../components/Loading/Loading";

import { HOST_URL } from '../constants/appConstants'
import { UserVerifyMail } from "../actions/userActions";

const VerifyMailScreen = ({history}) =>{
    const verifyMail = useSelector(state => state.verifyMail);
    console.log(verifyMail);
    const [isSending,setIsSending] = useState(false);
    const { loading, error, userInfo,userStatus } = verifyMail ? verifyMail: {};
    const [isLoading,setIsLoading] = useState(false);
    const dispatch = useDispatch();
    

    const token = userInfo ? userInfo.token : null;
    useEffect(()=>{
            if(userStatus){
                history.push('/userhome');
            }
            if(userInfo && !userStatus){
                setIsLoading(true);
                dispatch(UserVerifyMail(token));
                // await Axios.get(`${HOST_URL}/api/auth/verification/get-activation-email`, { headers: {"Authorization" : `Bearer ${token}`} })
                // .then((res)=>{
                //     console.log(res);
                // })
                // .catch(err=>{
                //     console.log(err);
                // })
                setIsLoading(false);
            }
            else{
                history.push('/');
            }
    },[userStatus,userInfo])
    const ResendRequest = useCallback(async () => {
        // don't send again while we are sending
        if (isSending) return
        // update state
        setIsSending(true)
        setIsLoading(true);
        dispatch(UserVerifyMail(token))
        // send the actual request
        // await Axios.get(`${HOST_URL}/api/auth/verification/get-activation-email`, { headers: {"Authorization" : `Bearer ${token}`} })
        // .then((res)=>{
        //     console.log(res);
        // })
        // .catch(err=>{
        //     console.log(err);
        // })
        // once the request is sent, update state again
        setIsSending(false)
        setIsLoading(false);
      }, [isSending]) // update the callback if the state changes
    return(
        <div className="d-flex justify-content-center align-items-center vh-100">
        { loading || isLoading ? (
            <Loading/>
        ) : (
            <div className="modal-dialog modal-dialog-centered" role="document">
                <div className="modal-content">
                    <div className="modal-body">
                        <p className="fs-3">An activation Mail has been sent to your mail.Please Check!</p>
                        <button className="btn btn-success" onClick={ResendRequest}>Resend Mail</button>
                    </div>
                </div>
            </div>
        )}
        </div>
    )
    
}

export default VerifyMailScreen;