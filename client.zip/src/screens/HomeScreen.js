import React, { useEffect } from 'react';
import { useDispatch,useSelector } from "react-redux";
import { useHistory,Link } from "react-router-dom";
import { validateToken } from '../actions/userActions';
import Loading from '../components/Loading/Loading'
import store from '../store'

const HomeScreen = ({history}) =>{

    const userLogin = useSelector(state => state.userLogin);
    const { loading, error, userInfo,userStatus } = userLogin ? userLogin : {};
    const token = userInfo ? userInfo.token : null;
    const dispatch = useDispatch();
    useEffect(()=>{
        if(token){
          dispatch(validateToken(token));
        }
      },[token])
    useEffect(()=>{
        console.log(userStatus);
        if(token && !userStatus){
            dispatch(validateToken(token));
          }
        else if(userStatus){
            history.push('/userhome');
        }
        else if(userInfo){
            history.push('/verify-mail');
        }
    },[userStatus,history,token])
    return(
        <div className="d-flex flex-column justify-content-center align-items-center vh-100">
            { loading ? (
                <Loading/>
            ) : (
                    <>
                        <div className="d-flex flex-column justify-content-evenly align-items-center h-25">
                            <h2 className="text-center">Welcome to your personalized TODO APP</h2>
                            <Link className="btn btn-outline-primary fs-4" to="/login">Log in</Link>  
                            <Link className="btn btn-outline-primary" to="/register">Register</Link>
                        </div>
                    </>
                )
            }
        </div>
        // <div className="d-flex flex-column justify-content-center align-items-center vh-100">    
        //     <div className="d-flex flex-column justify-content-evenly align-items-center h-25">
        //         <h2 className="text-center">Welcome to your personalized TODO APP</h2>
        //         <Link className="btn btn-outline-primary fs-4" to="/login">Log in</Link>  
        //         <Link className="btn btn-outline-primary" to="/register">Register</Link>
        //     </div>
        // </div>
    )
}

export default HomeScreen;